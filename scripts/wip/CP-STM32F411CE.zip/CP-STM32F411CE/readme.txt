Press boot then reset.
run the bootloader.bat file